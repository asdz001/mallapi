import requests
from lxml import etree
from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "GNB(BeeStore)의 fDisponibilita API를 사용해 상품 재고를 조회합니다."

    def add_arguments(self, parser):
        parser.add_argument(
            "--sku",
            type=str,
            default="2000014719293",  # 기본 테스트 SKU
            help="재고를 조회할 CodiceArticolo (SKU)"
        )

    def handle(self, *args, **options):
        sku = options["sku"]

        # ✅ SOAP 인증 및 설정 정보
        SOAP_USER = "milaneseb2b"
        SOAP_PSW = "w8Yc$K"
        SOAP_IGUNEGOZIO = "179"
        SOAP_ENDPOINT = "http://93.46.41.5:8180/milaneseb2b/soapBeestore.php"

        # ✅ SOAP XML 구성
        envelope = etree.Element(
            "soapenv:Envelope",
            nsmap={
                "soapenv": "http://schemas.xmlsoap.org/soap/envelope/",
                "urn": "urn:wsBeestore"
            }
        )
        body = etree.SubElement(envelope, "{http://schemas.xmlsoap.org/soap/envelope/}Body")
        method = etree.SubElement(body, "{urn:wsBeestore}fDisponibilita")

        etree.SubElement(method, "CodiceArticolo").text = sku
        etree.SubElement(method, "IGUNegozio").text = SOAP_IGUNEGOZIO
        etree.SubElement(method, "User").text = SOAP_USER
        etree.SubElement(method, "Password").text = SOAP_PSW

        # ✅ 전송
        xml_str = etree.tostring(envelope, pretty_print=True, encoding="utf-8", xml_declaration=True)
        headers = {"Content-Type": "text/xml; charset=utf-8"}

        self.stdout.write(f"\n🚀 GNB 재고조회 API 호출 중 (SKU: {sku})...")

        try:
            response = requests.post(SOAP_ENDPOINT, data=xml_str, headers=headers, timeout=30)
        except requests.RequestException as e:
            self.stderr.write(f"❌ 요청 실패: {e}")
            return

        self.stdout.write(f"🔁 HTTP 상태코드: {response.status_code}\n")
        self.stdout.write("📄 원시 응답 XML:")
        self.stdout.write(response.text)

        # ✅ Disponibilita 값 추출
        try:
            tree = etree.fromstring(response.content)
            disponibilita = tree.xpath("//Disponibilita/text()")
            if disponibilita:
                self.stdout.write(f"\n✅ 재고 수량: {disponibilita[0]}")
            else:
                self.stdout.write("⚠️ 'Disponibilita' 응답 없음. SKU가 존재하지 않거나 권한 없음.")
        except Exception as e:
            self.stderr.write(f"❌ XML 파싱 오류: {e}")
