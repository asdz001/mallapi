# 거래처(Retailer) 셋팅 정보

RETAILERS = {
    "MINETTI": {
        "USER_MKT": "TEST-HUB",
        "PWD_MKT": "4a11785b#S",
        "enabled": True
    },
    "BINI": {
        "USER_MKT": "TEST-HUB",
        "PWD_MKT": "4a11785b#S",
        "enabled": True 
    },
    "CUCCUINI": {
        "USER_MKT": "MILANESEKOREA",
        "PWD_MKT": "4RDf55<lwja*",
        "enabled": True
    }
}


 # 여기에 다른 거래처 계속 추가 가능