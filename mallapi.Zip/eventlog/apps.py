from django.apps import AppConfig

class EventlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eventlog'
    verbose_name = '5. 이벤트 로그'
